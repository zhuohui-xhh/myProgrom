export default class S11610{
    constructor(){
        this.name = "河豚手雷";
        this.ico = "./sources/skills/11210.png"
    }
}