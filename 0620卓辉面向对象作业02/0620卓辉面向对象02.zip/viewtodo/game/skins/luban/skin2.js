export default class Skin2{
    constructor(){
        this.name = "皮肤二";
        this.ico = "";
        this.img = "";
    }
}