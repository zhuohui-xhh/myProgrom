export default class Skin2{
    constructor(){
        this.name = "皮肤二";
        this.ico = "./sources/heros/yase2.png";
        this.img = "./sources/skins/301661.png";
    }
}