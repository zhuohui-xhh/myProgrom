export default class S11230{
    constructor(){
       this.name = "技能三";
       this.ico = "./sources/skills/11230.png"  
    }
}