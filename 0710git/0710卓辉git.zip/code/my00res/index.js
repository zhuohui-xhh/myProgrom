console.log("初始化内容");
console.log("第一次添加");