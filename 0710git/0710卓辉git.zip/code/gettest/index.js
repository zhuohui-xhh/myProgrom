console.log("初始化");
console.log("一些逻辑代码");
console.log("第二次提交代码");
// git add .  添加到暂存区  git commit -m :提交仓库； git status 查看状态； git log 查看提交日志（git log --oneline /git reflog）;
console.log("第三次添加的内容"); // git add .(所有修改的添加文件) ---> git commit -m "提交"   简化  git commit -a -m "提交到本地仓库"
console.log("提交代码");

// 删除 工作区 仓库 文件  git -rm 文件名；
// git -rm --catched 文件名  删除仓库里的内容；
console.log("添加内容");
console.log("再次添加内容");
// 创建分支 : git branch 分支名  切换分支   git checkout 分支名   ； 删除 git branch -d 分支名（合并）  git branch -D 分支名 （强制删除）;
// 添加了一些逻辑
