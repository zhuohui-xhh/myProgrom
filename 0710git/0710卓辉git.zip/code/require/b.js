console.log("b模块");
define({
    name:"b模块",
    age:21
})